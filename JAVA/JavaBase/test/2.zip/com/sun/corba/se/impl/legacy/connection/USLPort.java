/*
 * @(#)USLPort.java	1.8 10/03/23
 * 
 * Copyright (c) 2006, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.corba.se.impl.legacy.connection;

public class USLPort
{
    private String type;
    private int    port;

    public USLPort (String type, int port)
    {
	this.type = type;
	this.port = port;
    }

    public String getType  () { return type; }
    public int    getPort  () { return port; }
    public String toString () { return type + ":" + port; }
}

// End of file.

